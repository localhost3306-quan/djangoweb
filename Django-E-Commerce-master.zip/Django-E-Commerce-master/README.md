<b>Admin Superuser Information</b> <br>
<b>User Name :</b> admin<br>
<b>User Passw:</b> Qwert12345*<br>

# Django-E-Commerce
This project is a multilingual and multi-currency e-commerce Python Djnago web project.<br><br>
Youtube playlist  of the project (Playlist include 36 videos):<br>
https://www.youtube.com/playlist?list=PLIUezwWmVtFXaHcJ63ZM6uOJdhMrnZFFk <br>

Web Template of this prpoject:  https://colorlib.com/wp/template/e-shop/ <br>

<b> Downloading project:</b><br>
 Clone as zip file and open it your computer or if you have git application<br>
 https://github.com/celikyuksell/Django-E-Commerce.git<br>
 
<b>Before running this project you need intall below list apps and packages</b><br>

Install Python 3.7 or above -> https://www.python.org/<br>
Install Pip   -> python get-pip.py<br>

pip install Django<br>
pip install django-admin-thumbnails<br>
pip install django-ckeditor<br>
pip install django-currencies<br>
pip install django-mptt<br>
pip install Pillow<br>

<b>For running</b> <br>

python manage.py runserver<br>

<b>Playlist Video Topics</b> <br>
1 Django Installation Structure Introduction <br>
2 Django E Commerce css web template implementation <br>
3 Django E Commerce database model admin relation category and product image upload <br>
4 Django E Commerce Github <br>
5 Django E Commerce Product Image gallery <br>
6 Django E Commerce Implemet Richtext Editor Ckeditor <br>
7 Django E Commerce Setting About Contact pages <br>
8 Django E Commerce Contact Us Form and Messages <br>
9 Django E Commerce Category Tree Subcategory menu <br>
10 Django E Commerce Automatically Creating Slug for Category and Product <br>
11 Django E Commerce Dynamic Slider in homepage <br>
12 Django E Commerce products with images on homepage <br>
13 Django E Commerce Listing Category products <br>
14 Django E Commerce Search Products <br>
15 Django E Commerce Autocomplete in Search by Using AJAX JQuery <br>
16 Django E Commerce Product detail page with image gallery <br>
17 Django E Commerce Product Review Comment Rating <br>
18 Django E Commerce Shop cart Add list delete items <br>
19 Django E Commerce user profile information <br>
20 Django E Commerce user custom login logout user image <br>
21 Django E Commerce user signup form <br>
21a Django E Commerce Creating User profiles automatically at the User Signup time <br>
22 Django E Commerce order products <br>
23 Django E Commerce User Menu & Panel Profile Page <br>
24 Django E Commerce Update Change User & Profile Information <br>
25 Django E Commerce Change User Password <br>
26 Django E Commerce User Order Product List and Detail <br>
27 Django E Commerce User Comments List and Delete <br>
28 Django E Commerce Count and Average of Products Reviews <br>
29 Django E Commerce Frequently Asked Questions FAQ with Jquery ui Accordion <br>
30 Django E Commerce Product Attributes Variants Amazon style Size Color #1 <br>
31 Django E Commerce Product Attributes Variants Amazon style Size Color #2 <br>
32 Django E Commerce Access to functions from templates (Template Tags) <br>
33 Django E Commerce Multi Language on static html files and Urls Part1 <br>
34 Django E Commerce Multi Language on Database Models Part2 <br>
35 Django E Commerce Multi Language on Category Tree Recursive Function Part3 <br>
36 Django E Commerce Multi Currency <br>
